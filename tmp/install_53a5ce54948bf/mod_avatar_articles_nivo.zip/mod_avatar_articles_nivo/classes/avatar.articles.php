<?php
/**
 * @version		$Id: avatar.articles.php
 * @copyright	JoomAvatar.com
 * @author		Tran Nam Chung
 * @mail		chungtn@joomavatar.com
 * @link		http://joomavatar.com
 * @license		License GNU General Public License version 2 or later
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once JPATH_SITE.'/components/com_content/helpers/route.php';
jimport('joomla.application.component.model');
JModelLegacy::addIncludePath(JPATH_SITE.'/components/com_content/models', 'ContentModel');

if(class_exists('avatar_articles') != true)
{
	class avatar_articles
	{
		public static function getarticleTitle($params){
			return $params->get('articleTitle');
		}
		
		public static function getarticleIntro($params){
			return $params->get('articleIntro');
		}
		
		public static function getnewTab($params){
			return $params->get('newTab');
		}
		
		public static function getarticleLink($params){
			return $params->get('itemLink');
		}
		public static function getList(&$params)
		{
			// Get the dbo
			$db = JFactory::getDbo();
	
			// Get an instance of the generic articles model
			$model = JModelLegacy::getInstance('Articles', 'ContentModel', array('ignore_request' => true));
	
			// Set application parameters in model
			$app = JFactory::getApplication();
			$appParams = $app->getParams();
			$model->setState('params', $appParams);
	
			// Set the filters based on the module params
			$model->setState('list.start', 0);
			$model->setState('list.limit', $params->get('itemcount',3));
			$model->setState('filter.published', 1);
	
			// Access filter
			$access = !JComponentHelper::getParams('com_content')->get('show_noauth');
			$authorised = JAccess::getAuthorisedViewLevels(JFactory::getUser()->get('id'));
			$model->setState('filter.access', $access);
	
			// Category filter
			$model->setState('filter.category_id', $params->get('catid', array()));
	
			// Filter by language
			$model->setState('filter.language', $app->getLanguageFilter());
	
			//  Featured switch
			switch ($params->get('show_featured'))
			{
				case '1':
					$model->setState('filter.featured', 'only');
					break;
				case '0':
					$model->setState('filter.featured', 'hide');
					break;
				default:
					$model->setState('filter.featured', 'show');
					break;
			}
	
			// Set ordering
			$order_map = array(
				'm_dsc' => 'a.modified DESC, a.created',
				'mc_dsc' => 'CASE WHEN (a.modified = '.$db->quote($db->getNullDate()).') THEN a.created ELSE a.modified END',
				'c_dsc' => 'a.created',
				'p_dsc' => 'a.publish_up',
			);
			$ordering = JArrayHelper::getValue($order_map, $params->get('ordering'), 'a.publish_up');
			$dir = 'DESC';
	
			$model->setState('list.ordering', $ordering);
			$model->setState('list.direction', $dir);
	
			$items = $model->getItems();
	
			foreach ($items as &$item) {
				$item->slug = $item->id.':'.$item->alias;
				$item->catslug = $item->catid.':'.$item->category_alias;
	
				if ($access || in_array($item->access, $authorised)) {
					// We know that user has the privilege to view the article
					$item->link = JRoute::_(ContentHelperRoute::getArticleRoute($item->slug, $item->catslug));
				} else {
					$item->link = JRoute::_('index.php?option=com_users&view=login');
				}
			}
	
			return $items;
		}
	}
}
?>