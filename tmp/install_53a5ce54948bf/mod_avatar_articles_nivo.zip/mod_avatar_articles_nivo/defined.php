<?php
/**
 * @copyright	submit-templates.com
 * @license		GNU General Public License version 2 or later;
 */

// no direct access
defined('_JEXEC') or die;

define('AVATAR_NAME', 'mod_avatar_articles_nivo');
define('AVATAR_DIR', JPATH_ROOT.DIRECTORY_SEPARATOR.'modules'.DIRECTORY_SEPARATOR.AVATAR_NAME.DIRECTORY_SEPARATOR);

