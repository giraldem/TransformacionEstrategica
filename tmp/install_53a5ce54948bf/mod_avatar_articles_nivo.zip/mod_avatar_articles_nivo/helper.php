<?php
/**
 * @version		$Id: mod_avatar_articles_nivo.php
 * @copyright	JoomAvatar.com
 * @author		Tran Nam Chung
 * @mail		chungtn@joomavatar.com
 * @link		http://joomavatar.com
 * @license		License GNU General Public License version 2 or later
 */
defined( '_JEXEC' ) or die( 'Restricted access' );
class mod_avatar_articles_nivoHelper
{
}
?>