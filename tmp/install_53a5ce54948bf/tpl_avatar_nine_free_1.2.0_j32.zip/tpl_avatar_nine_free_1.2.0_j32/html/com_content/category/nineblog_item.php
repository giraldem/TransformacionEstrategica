<?php
/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   Copyright (C) 2005 - 2013 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;?>
<?php
// Create a shortcut for params.
$params = $this->item->params;
$images = json_decode($this->item->images);
JHtml::addIncludePath(JPATH_COMPONENT.'/helpers/html');
$canEdit = $this->item->params->get('access-edit');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.framework');
if ($params->get('access-view')) :
	$link = JRoute::_(ContentHelperRoute::getArticleRoute($this->item->slug, $this->item->catid));
else :
	$menu = JFactory::getApplication()->getMenu();
	$active = $menu->getActive();
	$itemId = $active->id;
	$link1 = JRoute::_('index.php?option=com_users&view=login&Itemid=' . $itemId);
	$returnURL = JRoute::_(ContentHelperRoute::getArticleRoute($this->item->slug, $this->item->catid));
	$link = new JUri($link1);
	$link->setVar('return', base64_encode($returnURL));
endif;
?>
<?php if ($this->item->state == 0) : ?>
	<span class="label label-warning"><?php echo JText::_('JUNPUBLISHED'); ?></span>
<?php endif; ?>
<?php if ($params->get('show_print_icon') || $params->get('show_email_icon') || $canEdit) : ?>
<div class="avatar-pee">
		<?php if ($params->get('show_print_icon')) : ?>
		<div class="print-icon"> <?php echo JHtml::_('icon.print_popup', $this->item, $params); ?> </div>
		<?php endif; ?>
		<?php if ($params->get('show_email_icon')) : ?>
		<div class="email-icon"> <?php echo JHtml::_('icon.email', $this->item, $params); ?> </div>
		<?php endif; ?>
		<?php if ($canEdit) : ?>
		<div class="edit-icon"> <?php echo JHtml::_('icon.edit', $this->item, $params); ?> </div>
		<?php endif; ?>
		<div class="clr"></div>
</div>
<?php endif; ?>

<?php if ($params->get('show_title')) : ?>
				<div class="avatar-item-title">
					<h2>
						<?php if ($this->item->state == 0) : ?>
							<span class="label label-warning"><?php echo JText::_('JUNPUBLISHED'); ?></span>
						<?php endif; ?>
						<?php if ($params->get('show_title')) : ?>
							<?php if ($params->get('link_titles')) : ?>
								<a href="<?php echo $link; ?>"> <?php echo $this->escape($this->item->title); ?></a>
							<?php else : ?>
								<?php echo $this->escape($this->item->title); ?>
							<?php endif; ?>
						<?php endif; ?>
					</h2>
				</div>	
				<?php endif; ?>


<?php  if (isset($images->image_intro) and !empty($images->image_intro)) : ?>
   <?php $imgfloat = (empty($images->float_intro)) ? $params->get('float_intro') : $images->float_intro; ?>
   <div class="avatar-item-intro-img img-intro-<?php echo htmlspecialchars($imgfloat); ?>">	
   <div class='avatar-image-inner'>
   	<div style="position: relative;">
	   	<img
	      <?php if ($images->image_intro_caption):
	         echo 'class="caption"'.' title="' .htmlspecialchars($images->image_intro_caption) .'"';
	      endif; ?>
	      src="<?php echo htmlspecialchars($images->image_intro); ?>" alt="<?php echo htmlspecialchars($images->image_intro_alt); ?>"/>
    	<div class="avatar-shadow-inset"></div>
		<?php
			$id = uniqid(); 
			echo '<a class="avatar_zoom_btn" href="#avatar_image_'.$id.'" data-toggle="modal">'.'<div class="avatar-zoom-icon"></div></a>';
		?>
    	<?php if ($params->get('show_readmore') && $this->item->readmore) :?>
   			<a class="avatar-readmore-btn" href="<?php echo $link; ?>">
   				<div class="avatar-readmore-icon"></div>
   			</a>
   		<?php endif;?>
    </div>
   </div>
   
   </div> 
<?php endif; ?>
<?php $useDefList = ($params->get('show_modify_date') || $params->get('show_create_date') || $params->get('show_hits') || $params->get('show_category') || $params->get('show_parent_category') || $params->get('show_author') || $params->get('show_title')); ?>
<?php if($useDefList):?>
			<div class="avatar-item-image-below">
				<?php if ($params->get('show_modify_date') || $params->get('show_create_date') || $params->get('show_hits') || $params->get('show_category') || $params->get('show_parent_category')) : ?>
					<div class="avatar-article-info">
						
						<?php if ($params->get('show_parent_category') && !empty($this->item->parent_slug)) : ?>
							<div class="parent-category-name">
								<?php $title = $this->escape($this->item->parent_title);
								$url = '<a href="'.JRoute::_(ContentHelperRoute::getCategoryRoute($this->item->parent_slug)) . '"><strong>' . $title . '</strong></a>';?>
								<?php if ($params->get('link_parent_category') && !empty($this->item->parent_slug)) : ?>
									<?php echo JText::sprintf('COM_CONTENT_PARENT', $url); ?>
								<?php else : ?>
									<?php echo JText::sprintf('COM_CONTENT_PARENT', '<strong>'.$title.'</strong>'); ?>
								<?php endif; ?>
							</div>
						<?php endif; ?>
						<?php if ($params->get('show_category')) : ?>
							<div class="category-name">
								<?php $title = $this->escape($this->item->category_title);
								$url = '<a href="' . JRoute::_(ContentHelperRoute::getCategoryRoute($this->item->catslug)) . '"><strong>' . $title . '</strong></a>';?>
								<?php if ($params->get('link_category') && $this->item->catslug) : ?>
									<?php echo JText::sprintf('COM_CONTENT_CATEGORY', $url); ?>
								<?php else : ?>
									<?php echo JText::sprintf('COM_CONTENT_CATEGORY', '<strong>'.$title.'</strong>'); ?>
								<?php endif; ?>
							</div>
						<?php endif; ?>
									
						<?php if ($params->get('show_modify_date')) : ?>
							<div class="modified">
								<?php echo JText::sprintf('COM_CONTENT_LAST_UPDATED', JHtml::_('date', $this->item->modified, JText::_('DATE_FORMAT_LC3'))); ?>
							</div>
						<?php endif; ?>
						<?php if ($params->get('show_create_date')) : ?>
							<div class="create">
								<?php echo JText::sprintf('COM_CONTENT_CREATED_DATE_ON', JHtml::_('date', $this->item->created, JText::_('DATE_FORMAT_LC3'))); ?>
							</div>
						<?php endif; ?>
						
						<?php if ($params->get('show_hits')) : ?>
							<div class="hits">
								<?php echo JText::sprintf('COM_CONTENT_ARTICLE_HITS', $this->item->hits); ?>
							</div>
						<?php endif; ?>
			
					</div>
				<?php endif; ?>
				<?php if (!$params->get('show_intro')) : ?>
					<?php echo $this->item->event->afterDisplayTitle; ?>
				<?php endif; ?>
				
				<?php echo $this->item->event->beforeDisplayContent; ?> <?php echo $this->item->introtext; ?>
				
				<?php if ($params->get('show_tags', 1) && !empty($this->item->tags)) : ?>
					<?php $this->item->tagLayout = new JLayoutFile('joomla.content.tags'); ?>
			
					<?php echo $this->item->tagLayout->render($this->item->tags->itemTags); ?>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<div class="avatar-item-bottom">
			<?php if ($params->get('show_publish_date')) : ?>
				<div class="avatar-publish-date">
					<?php echo JText::sprintf(JHtml::_('date', $this->item->publish_up, JText::_('DATE_FORMAT_LC3'))); ?>
					<?php echo ", ";?>
				</div>
			<?php endif; ?>
			<?php if ($params->get('show_author') && !empty($this->item->author )) : ?>
				<div class="createdby">
				<?php $author = $this->item->author;?>
				<?php $author = ($this->item->created_by_alias ? $this->item->created_by_alias : $author); ?>
				<?php if (!empty($this->item->contactid ) && $params->get('link_author') == true) : ?>
					<?php
					echo JText::sprintf(
					'COM_CONTENT_WRITTEN_BY',
					JHtml::_('link', JRoute::_('index.php?option=com_contact&view=contact&id=' . $this->item->contactid), '<strong>'.$author.'</strong>')
					); ?>
				<?php else :?>
					<?php echo JText::sprintf('COM_CONTENT_WRITTEN_BY', '<strong>'.$author.'</strong>'); ?>
				<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
		
	<?php if (isset($images->image_intro) and !empty($images->image_intro)) : ?>
	<div id="avatar_image_<?php echo $id;?>" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	  <div class="modal-body">
	    <img class="avatar_modal_image" src="<?php echo htmlspecialchars($images->image_intro);?>">
	  </div>
	  <div class="modal-footer">
	    <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
	  </div>
	</div>
	<?php endif;?>

<?php echo $this->item->event->afterDisplayContent; ?>
